<?php 

$token="7146948236:AAFb3GIxxcsiJLpbn2USwWxpQSpRh0RPIuU";
$id= 6157045203;
$apikey="AAAA0CNBruQ:APA91bGsWIaXUv2L9PCZAbWub3eWQjhmZI3GFm9K64jQaYSUMNOLex3iS2fZibCi2-_2OSL_8X-qY5kzaq1ZjXgNe9JhosU706D8677ZWflWmLQLJ-h1UvwUDUk9dHlwtN4zdL7qauJO";
$prt="H3bit";
$crd="@h3bit";
$admin_list=[-1002069606368];

?>